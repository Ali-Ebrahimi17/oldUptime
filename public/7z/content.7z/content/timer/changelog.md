## 1.1.0 (Dec 30, 2018)

Bugfixes:
  - Fixed: Initial hours more than a day don't show
  
Features:

  - Added destroy method
  - Added new option to display the milliseconds next to the seconds in the full view format

## 1.0.1 (May 31, 2017)

Bugfixes:

  - Avoiding leading zeros when using the full mode view with hours in order to display it correctly

## 1.0.0 (March 28, 2017)

Features:

  - First version and release
